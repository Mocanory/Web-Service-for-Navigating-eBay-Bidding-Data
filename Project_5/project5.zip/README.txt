================================================================================
This File is created for CS-144 Project 5.
Team member:
              Yue Xin    (UID: 204775695)  <yuexin@cs.ucla.edu>
              Zhehan Li  (UID: 404888352)  <lizhehan@cs.ucla.edu>
================================================================================

Q1: For which communication(s) do you use the SSL encryption? 

Ans: (4)→(5) and (5) (6).

Q2: How do you ensure that the item was purchased exactly at the Buy_Price of that particular item?

Ans: We use a session to store all information of the item in the same servlet. The info is stored in the server to make sure that users have no chance to manipulate the price. 

================================================================================
This File is created for CS-144 Project 5.
Team member:
              Yue Xin    (UID: 204775695)  <yuexin@cs.ucla.edu>
              Zhehan Li  (UID: 404888352)  <lizhehan@cs.ucla.edu>
================================================================================
