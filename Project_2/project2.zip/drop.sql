-- Should be the reversed order according to create.sql

DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Bid;
DROP TABLE IF EXISTS Item;
DROP TABLE IF EXISTS Seller;
DROP TABLE IF EXISTS Bidder;
